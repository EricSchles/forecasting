forecasting
===========

**forecasting** provides a toolkit with for doing timeseries prediction.
This project builds heavily on the work of
`scikit-learn <https://pypi.python.org/pypi/scikit-learn>`

Features
--------

-  algorithms
-  helpers

   
Requirements
------------

-  `statsmodels <https://pypi.python.org/pypi/statsmodels>`__
-  `scipy <https://pypi.python.org/pypi/scipy>`__
-  `pandas <https://pypi.python.org/pypi/pandas>`__
-  `numpy <https://pypi.python.org/pypi/numpy>`__
-  `sklearn <https://pypi.python.org/pypi/scikit-learn>`__
   
Examples
--------

Examples are coming soon.


License
-------

forecaster is available under the GNU General Public License, version 3.
See LICENCE for more details.
